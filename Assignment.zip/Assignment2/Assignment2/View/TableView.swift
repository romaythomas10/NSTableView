

import SwiftUI
import AVKit

struct TableView: View {
    @ObservedObject var viewModel: TableDataViewModel = TableDataViewModel()
    @State var floatingImage: UIImage?
    @State var floatingVideo: String?
    
    var body: some View {
        ZStack{
            ActivityIndicatorView(isAnimating: self.viewModel.fetchFinished)
            VStack{
                if viewModel.pageNumber > 0 {
                    Text("Page \(viewModel.pageNumber)")
                }
                List{
                    ForEach(viewModel.images, id: \.self) { item in
                        VStack{
                            HStack{
                                Spacer()
                                if item.image != nil {
                                    Image(uiImage: item.image!)
                                        .resizable()
                                        .frame(width: 250, height: 250)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 5)
                                                .stroke(Color.blue)
                                    )
                                        .onTapGesture {
                                            self.floatingImage = item.image
                                    }
                                }
                                if item.video != nil {
                                    FloatingVideoView()
                                }
                                Spacer()
                            }
                       
                        }
                        .rotationEffect(.radians(.pi))
                        .scaleEffect(x: -1, y: 1, anchor: .center)
                    }
                }
                .rotationEffect(.radians(.pi))
                .scaleEffect(x: -1, y: 1, anchor: .center)
                HStack{
                    Spacer()
                    Button(action: {
                        self.viewModel.fetchFromAPI()
                    }) {
                        Image(systemName: "forward.fill")
                            .foregroundColor(.blue)
                    }
                    Spacer()
                }//.padding()
            }.onAppear {
                self.viewModel.fetchFromAPI()
            }
            if floatingImage != nil {
                HStack{
                    Spacer()
                    FloatingImageView(image:self.$floatingImage)
                    Spacer()
                }
                .offset(x: 0, y: -200)
            }
        }
    }
}

struct TableView_Previews: PreviewProvider {
    static var previews: some View {
        TableView()
    }
}
struct FloatingImageView: View {
    @Binding var image: UIImage?
    
    var body: some View {
        ZStack{
            if self.image != nil {
                Image(uiImage: self.image!)
                    .resizable()
                    .frame(width: 200, height: 200)
                    .overlay(
                        RoundedRectangle(cornerRadius: 6)
                            .stroke(Color.blue)
                )
            }
            Button(action: {
                if self.image != nil {
                    self.image = nil
                }
            }) {
                Image(systemName: "multiply.circle.fill")
                    .resizable()
                    .frame(width: 30, height: 30)
                    .foregroundColor(.gray)
                    .background(Color.white)
                
            }
            .offset(x: 190, y: -185)
        }
    }
}

struct FloatingVideoView: View{
    @Environment(\.presentationMode) var presentationMode
    @State var player =  AVPlayer(url: URL(string: "https://www.radiantmediaplayer.com/media/bbb-360p.mp4")!)
    @State var play: Bool = false
    @State var isPlaying: Bool = false
    @State var isFullScreen: Bool = false
    @State var presentSheet: Bool = false
    var body: some View{
        ZStack{
            VideoPlayer(player: self.$player)
                .frame(width: 250, height: 250)
            VStack{
                HStack{
                    Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                        .resizable()
                        .frame(width: 25, height: 25)
                        .onTapGesture {
                            self.isPlaying.toggle()
                            if self.isPlaying {
                                self.player.play()
                            } else {
                                self.player.pause()
                            }
                    }
                    Spacer()
                    if self.isPlaying {
                        Image(systemName:  "arrow.up.left.and.arrow.down.right")
                            .resizable()
                            .frame(width: 25, height: 25)
                            .onTapGesture {
                                self.isFullScreen.toggle()
                        }
                    }
                }
                .padding()
                .frame(width: 250)
                .background(Color.gray)
                Spacer()
            }
            
        }.sheet(isPresented: $isFullScreen) {
            FullScreenVideo(player: self.$player, isPlaying: self.$isPlaying)
        }
    }
}

extension AVPlayer {
    var isPlaying: Bool {
        return rate != 0 && error == nil
    }
}

struct FullScreenVideo: View {
    @Environment(\.presentationMode) var presentationMode
    @Binding var player: AVPlayer
    @Binding var isPlaying: Bool
    var body: some View {
        ZStack{
            VideoPlayer(player: self.$player)
            VStack{
                HStack{
                    Spacer()
                    Image(systemName: "multiply.circle.fill")
                        .resizable()
                        .frame(width: 25, height: 25)
                        .onTapGesture {
                            self.presentationMode.wrappedValue.dismiss()
                    }
                }.padding()
                    .background(Color.gray)
                    .padding()
                    .onAppear{
                        self.player.play()
                }
                Spacer()
            }
        }
    }
}
