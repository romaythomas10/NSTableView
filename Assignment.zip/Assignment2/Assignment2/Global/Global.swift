
import SwiftUI


public enum GlobalConstants: String {
    case production
    case development
}

extension GlobalConstants {
    static let DogBaseAPILink: String = {
        return "https://dog.ceo"
    }()
    static let QuoteAPILink: String = {
        return "https://jsonplaceholder.typicode.com"
    }()
}
