

import Foundation
struct DogResource {
    var numberOfImages: Int
}


// https://dog.ceo/api/breeds/image/random
extension DogResource: ResourceType {
    var baseURL: URL {
        guard let url = URL(string: GlobalConstants.DogBaseAPILink) else { fatalError("baseURL could not be configured.") }
        return url
    }
    var path: String {
        return "/api/breeds/image/random/\(numberOfImages)"
    }
    var parameter: Parameters {
        let param = [String: String]()
        return param
    }
    var httpMethod: HTTPMethod {
        return .get
    }
    var task: HTTPTask {
        return .requestParametersAndHeaders(bodyParameters: nil, bodyEncoding: .urlEncoding , urlParameters: parameter, additionHeaders: nil)
    }
}
