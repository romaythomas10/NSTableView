

import SwiftUI

protocol DogServiceType: class {
    func getDogImages(numberOfImages: Int, completion: @escaping(Result<DogModel?, APIError>)->Void)
}

class DogService: DogServiceType {
    var requestManager: RequestManagerType = RequestManager()
    
    func getDogImages(numberOfImages: Int, completion: @escaping (Result<DogModel?, APIError>) -> Void) {
        
        let resource = DogResource(numberOfImages: numberOfImages)
        
        guard let request = try? resource.makeRequest() else { return }
        //print(request.url)
        
        requestManager.fetch(with: request, decode: {
            json -> DogModel? in
            
            guard let model = json as? DogModel else { return nil }
            
            return model
        }, completion: completion)
    }
    
    
}
