

import SwiftUI

protocol TodosServiceType: class {
    func getDogImages(numberOfImages: Int, completion: @escaping(Result<[TodosModel]?, APIError>)->Void)
}

class TodosService: TodosServiceType {
    var requestManager: RequestManagerType = RequestManager()
    
    func getDogImages(numberOfImages: Int, completion: @escaping (Result<[TodosModel]?, APIError>) -> Void) {
        
        let resource = TodosResource()
        
        guard let request = try? resource.makeRequest() else { return }
        //print(request.url)
        
        requestManager.fetch(with: request, decode: {
            json -> [TodosModel]? in
            
            guard let geoLocationModel = json as? [TodosModel] else { return nil }
            
            return geoLocationModel
        }, completion: completion)
    }
    
    
}
