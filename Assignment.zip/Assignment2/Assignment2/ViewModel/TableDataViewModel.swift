

import SwiftUI

struct Thumbnil: Identifiable, Hashable{
    var id = UUID()
    var image: UIImage?
    var video: String?
    var isVideo: Bool = false
}


class TableDataViewModel: ObservableObject{
    @EnvironmentObject var tableData: TableData
    @Published var images: [Thumbnil] = []
    @Published var pageNumber: Int = 0
    private let numberOfRecords: Int = 10
    private let imageService = ImageService.shared
    @Published var fetchFinished: Bool = false
    
    func fetchFromAPI(){
        let dogService = DogService()
        dogService.getDogImages(numberOfImages: numberOfRecords) { (result) in
            switch result{
            case .success(let models):
                if let models = models,
                    let status = models.status, status == "success",
                    let message = models.message{
                    for (index,message) in message.enumerated() {
                        var thumbnil = Thumbnil()
                        if index % 3 == 0 {
                            if index % 2 == 0 {
                                thumbnil.image = nil
                                thumbnil.video = ""
                                thumbnil.isVideo = true
                            } else {
                                thumbnil.image = UIImage()
                                thumbnil.video = message
                                thumbnil.isVideo = false
                            }
                            self.images.append(thumbnil)
                        } else {
                            if index % 2 == 1 {
                                thumbnil.image = nil
                                thumbnil.video = ""
                                thumbnil.isVideo = true
                            } else {
                                thumbnil.image = UIImage()
                                thumbnil.video = message
                                thumbnil.isVideo = false
                            }
                            self.images.insert(thumbnil, at: 0)
                        }
                    }
                    var currentIndex = 0
                    for (index,image) in self.images.enumerated() {
                        if !image.isVideo, let imageURL = self.images[index].video, let url = URL(string: imageURL) {
                            self.images[index].video = nil
                            self.imageService.retrieveImage(withURL: url) { (uiImage) in
                                if let uiImage = uiImage {
                                    self.images[index].image = uiImage
                                }
                            }
                        }
                        currentIndex += 1
                        
                    }
                    if message.count > 0 {
                        self.pageNumber += 1
                    }
                } else {
                    print("The API call failed..")
                }
            case .failure(let error):
                print("There is an fetching data: \(error.localizedDescription)")
            }
        }
    }
}
