

import SwiftUI


struct TableRow: Codable, Identifiable, Hashable{
    var id = UUID()
    var image: String = ""
    var name: String = ""
}

class TableData: ObservableObject{
    @Published var list: [TableRow] = []
    @Published var selectedRow: Int = 0
    
    var image: String  {
        if selectedRow < list.count{
            return list[selectedRow].image
        } else {
            return ""
        }
    }
    var name: String  {
        if selectedRow < list.count{
            return list[selectedRow].name
        } else {
            return ""
        }
    }
    var selectedRowData: TableRow? {
        if selectedRow < list.count {
            return list[selectedRow]
        }
        return nil
    }
}

